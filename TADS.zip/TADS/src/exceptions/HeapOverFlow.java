package exceptions;

public class HeapOverFlow extends RuntimeException {
}
