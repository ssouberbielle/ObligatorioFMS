package exceptions;

public class EmptyStackException extends Exception {
}
