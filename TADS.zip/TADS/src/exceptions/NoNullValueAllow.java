package exceptions;

public class NoNullValueAllow extends RuntimeException {
}
