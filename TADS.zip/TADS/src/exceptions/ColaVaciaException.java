package exceptions;

public class ColaVaciaException extends Exception {
}
