package exceptions;

public class EmptyHeap extends RuntimeException {
}
