package exceptions;

public class EmptyList extends RuntimeException {
}
